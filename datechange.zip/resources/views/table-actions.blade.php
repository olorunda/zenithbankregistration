<a href="{{ route('portal.view-registration', $token) }}" class="bg-red-600 text-white py-1 px-2 rounded-md" title="View">
    <i class="fas fa-eye"></i>
</a>
